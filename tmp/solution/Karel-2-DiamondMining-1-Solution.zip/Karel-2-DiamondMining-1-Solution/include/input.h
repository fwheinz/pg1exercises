#include "structs.h"

extern Input input;
extern World world;
extern Karel karel;
