#include "structs.h"

extern SDL_Surface *screen, *wallVerticalImage, *karelImage;
extern TTF_Font *font;
extern World world;
